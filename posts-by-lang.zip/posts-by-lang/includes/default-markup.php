<?php
function pbl_get_default_markup(){
    $default_markup     =   '<div class="pbl-item">
                                <div class="pbl-title"><a href="{link}">{title}</a></div>
                                <a class="pbl-thumbnail" href="{link}">
                                    {thumbnail}
                                </a>
                                <div class="pbl-meta">
                                    <div class="pbl-author">
                                        <a href="{author-url}">{author-name}</a>
                                    </div>
                                    <div class="pbl-date">
                                        {date}
                                    </div>
                                    <div class="pbl-terms">
                                        {terms}
                                    </div>
                                </div>
                                <div class="pbl-content">
                                    {excerpt}
                                </div>
                            </div>';
    
    return $default_markup;
}