<?php
function pbl_lang_detect( $lang_detect = "polylang", $parent_id ) {

    $lang = "";

    switch ( $lang_detect ) {

        case "polylang":
            $lang = pll_current_language();
            break;
        
        case "locale";
            $lang = str_replace( "_", "-", get_locale() );
            break;

        case "bloginfo";
            $lang = get_bloginfo('language');
            break;

        case "parent";
            $lang = pll_get_post_language( $parent_id );
            break;

        default:
            $lang = pll_get_post_language( $parent_id );
            break;
    }

    return $lang;
}