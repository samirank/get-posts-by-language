<?php 
/* 
Plugin Name: Display posts by current language
Description: Display Recent posts by page language
Version: 1.0.1
Author: Samiran K
Author URI: https://samirankakoty.com
Text Domain: pbl
Domain Path: /languages
 */

// Setup
if ( !function_exists( 'add_action' ) ) {
    echo "This plugin cannot be accessed directly.";
    exit;
}

// Includes
include( 'includes/activate.php' );
include( 'includes/init.php' );
include( 'includes/default-markup.php' );
include( 'includes/lang-detect.php' );
include( 'query.php' );

// Hooks
register_activation_hook( __FILE__, 'pbl_activate_plugin' );
add_action ( 'init', 'pbl_init' );

// Shortcodes
add_shortcode( 'pbl', 'pbl_shortcode_function' );