<?php

function pbl_shortcode_function( $atts = array(), $content = null ) {

    global $post;

    $atts = shortcode_atts( array(
		'lang'              => '',
        'cat_sep'           => ', ',
        'lang_detect'       => 'polylang', //E.g. 'polylang', 'slug', 'bloginfo', 'locale', 'current'
        'offset'            => 0,
        'posts_per_page'    => 10,
        'order'             => 'DESC',
        'orderby'           => 'date',  
        'post_type'         => 'post',   
        'post_status'       => 'publish'   
    ), $atts );
    
    $lang = $atts['lang'];    
    $lang_detect = $atts['lang_detect'];
    $offset = $atts['offset'];
    $posts_per_page = $atts['posts_per_page'];
    $order = $atts['order'];
    $orderby = $atts['orderby'];
    $post_type = $atts['post_type'];
    $post_status = $atts['post_status'];
    $cat_sep = $atts['cat_sep'];
    $parent_id = $post->ID;
    
    
    if( empty( $lang ) ){
        $lang = pbl_lang_detect( $lang_detect, $parent_id );
    }

    $paged = ( get_query_var('paged') ) ? get_query_var('paged') : 1;
    
    $query_args = array (
        'post_type'      => $post_type,
        'lang'           => $lang,    // use language slug in the query
        'paged'          => $paged,
        'posts_per_page' => $posts_per_page,
        'post_status'    => $post_status,
        'offset'         => $offset,
        'order'          => $order
    );
    
    $posts = new WP_Query( $query_args );
    $output = "";

    // The Loop
    while ( $posts->have_posts() ) {
        $posts->the_post();
        global $post;
        
        if ( !empty( $content ) ) {
            $markup = $content;
        } else {
            $markup = pbl_get_default_markup();
        }

        // Replace {title} with get_the_title()
        $markup = str_replace( '{title}', get_the_title(), $markup );

        // Replace {link} with get_the_permalink() 
        $markup = str_replace( '{link}', get_the_permalink(), $markup );

        // Replace {thumbnail-url} with get_the_permalink() 
        $markup = str_replace( '{thumbnail-url}', get_the_post_thumbnail_url(), $markup );

        // Replace {thumbnail-alt} with $thumbnail_alt
        $thumbnail_id = get_post_thumbnail_id( $post->ID );
        $thumbnail_alt = get_post_meta($thumbnail_id, '_wp_attachment_image_alt', true);
        if ( empty( $thumbnail_alt ) ) {
            $thumbnail_alt = get_the_title();
        }
        $markup = str_replace( '{thumbnail-alt}', $thumbnail_alt, $markup );

        // Replace {thumnbail}
        $markup = str_replace( '{thumbnail}', get_the_post_thumbnail( 'full' ), $markup );

        // Replace {author-url}
        $author_url = get_author_posts_url( get_the_author_meta( 'ID' ) );
        $markup = str_replace( '{author-url}', $author_url, $markup );

        // Replace {author-name}
        $markup = str_replace( '{author-name}', get_the_author(), $markup );

        // Replace {date}
        $markup = str_replace( '{date}', get_the_date(), $markup );

        // Replace {terms}
        $categories = get_the_category();
        $cats = '';
        foreach ( $categories as $category ) {
            $cats .=  '<a href="' . esc_url( get_category_link( $category->term_id ) ) . '">' . esc_html( $category->name ) . '</a>' . $cat_sep;
        }
        $cats = trim( $cats, $cat_sep );

        $markup = str_replace( '{terms}', $cats, $markup );

        // Replace {excerpt}
        $markup = str_replace( '{excerpt}', get_the_excerpt(), $markup );

        // Replace {lang}
        $markup = str_replace( '{lang}', pll_get_post_language( $post->ID ), $markup );

        $output .= $markup;

    }
    // End while

    wp_reset_postdata();

    
    // do something to $content
 
    // always return
    return $output;
}


